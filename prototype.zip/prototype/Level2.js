export default class Level2 extends Phaser.Scene {
    
    constructor(){
        super('Level2');
        
    }
  
    preload() {
        this.load.atlas('dude','assets/dudeg.png','assets/dude.json');
        this.load.image('char','assets/char.jpg');
        this.load.image('platform', 'assets/platformg.jpg');
        this.load.image('bg', 'assets/bgx.jpg');
        this.load.image('lava', 'assets/lava.png');
        this.load.image('goal', 'assets/win.jpg');
    }
create() {
    this.winText = "";
    this.jumpCount = 0;
    
    this.wins = 0;
    
    this.add.image(400, 300, 'bg');
    this.platforms = this.physics.add.staticGroup();
    this.deathLava = this.physics.add.staticGroup();
    this.goal = this.physics.add.staticGroup();

    this.deathLava.create(400, 586, 'lava').setScale(100, 5).refreshBody();
    this.platforms.create(100, 600, 'platform').setScale(2, 10).refreshBody();
    this.platforms.create(420, 600, 'platform').setScale(2, 15).refreshBody();
    this.platforms.create(500, 600, 'platform').setScale(2, 20).refreshBody();
    this.goal.create(700, 400, 'goal').setScale(5, 2).refreshBody();


    this.player = this.physics.add.sprite(75, 485, 'dude');
    this.player.setScale(.25);
    this.player.setBounce(0.2);
    this.player.setCollideWorldBounds(true);



    this.physics.add.collider(this.platforms, this.player);
    this.physics.add.overlap(this.deathLava, this.player, this.death,null,this);
    this.physics.add.collider(this.goal, this.player, this.win,null,this);

    this.winText = this.add.text(0,0,'OMEGALUL');
    this.controls = this.input.keyboard.createCursorKeys();
    this.spaceBar = this.input.keyboard.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE);
    this.anims.create({
        key: 'move_right',
        frames: this.anims.generateFrameNames('dude', { prefix: 'moving', end: 1, zeroPad: 3}), repeat: -1});

    this.anims.create({
        key: 'standing',
        frames: this.anims.generateFrameNames('dude', { prefix: 'standing', end: 1, zeroPad: 3}), repeat: -1
    
    });
    this.anims.create({
        key: 'jumping',
        frames: this.anims.generateFrameNames('dude', { prefix: 'jumping', end: 1, zeroPad: 3}), repeat: -1
    
    });


    
}

update() {
    const upPress = Phaser.Input.Keyboard.JustDown(this.controls.up);
    
    const touchFloor = this.player.body.touching.down;
    this.gameOver;
if(this.gameOver){



this.registry.destroy();
this.events.off();
this.scene.restart();
this.gameOver = false;


}
    
    if (this.controls.left.isDown) {
        this.player.setVelocityX(-160);
        this.player.flipX = true;if(!touchFloor)
        {
            this.player.anims.play('jumping',true);
        }
        else{
        this.player.anims.play('move_right',true);
        }
    } else if (this.controls.right.isDown) {
        this.player.setVelocityX(160);
        this.player.flipX = false;
        if(!touchFloor)
        {
            this.player.anims.play('jumping',true);
        }
        else{
        this.player.anims.play('move_right',true);
        }
    } else {
        this.player.setVelocityX(0);
        this.player.anims.play('standing',true);
    }
    
    if (upPress && touchFloor) {
        this.player.setVelocityY(-220);
        this.jumpCount++;
    }
    if (upPress && (!touchFloor && this.jumpCount < 2)) {
        this.player.setVelocityY(-220);
        this.jumpCount++;
    }
    if (touchFloor && !upPress) {
        this.jumpCount = 0;
    }
}
win(player,goal) {
    if(this.player.body.touching.down)
    {
        this.wins++;
        this.winText.setText('Score: ' + this.wins);
        this.player.x = 75;
        this.player.y = 480;
    }
}

death(player, deathLava) {
    this.gameOver = true;
}
}