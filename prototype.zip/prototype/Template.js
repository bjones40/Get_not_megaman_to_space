export default class Class_Title_Here extends Phaser.Scene {

    constructor() {
        super("Internal_Reference_Name_Here");
    }

    preload() {
        this.remember_all_variables_need_this_operator = 0;
    }

    create() {
        no_function_word_on_functions() {
            this.remember_all_variables_need_this_operator++;
        }
    }

    update() {
        this.no_function_word_on_functions();
    }
}